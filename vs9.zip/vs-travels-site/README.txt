VS Travels India - Website
===========================
Files:
- index.html   -> Main homepage (Hero, Services, Tour Packages, Why Choose Us, Destinations, Testimonials, FAQ, Contact Form)
- gallery.html -> Photo Gallery page with filters + click-to-enlarge lightbox

How to use:
1. Extract this zip file (keep index.html and gallery.html in the SAME folder — gallery links to index.html and vice versa).
2. Double-click index.html to open the site in your browser.
3. To host it live, upload both files to any hosting service (Hostinger, GitHub Pages, Netlify, etc.) or send to a web developer to connect your domain.

Features included:
- Hero section with WhatsApp CTA
- Services strip (Flights, Hotels, Bus, Train, Holiday Packages)
- Tour Packages section with pricing cards (placeholder prices — update anytime)
- Why Choose Us section
- Popular Destinations gallery
- Customer Testimonials (placeholder reviews — replace with real ones anytime)
- FAQ accordion
- Contact form -> auto-generates a WhatsApp message with the visitor's details
- Dedicated Photo Gallery page with category filters and lightbox viewer
- Floating WhatsApp button on every page

Contact details used in the site:
WhatsApp/Call: 9587370020
Email: vstravelsindiaa@gmail.com
Location: Jaipur, Rajasthan, India

Note: Images load from free stock photo sources (Unsplash) via internet links, so an internet connection is needed to see them. Replace image URLs in the HTML files with your own hosted photos any time.

New MakeMyTrip-style features added:
- Flight / Hotel / Bus / Train search bar (tabs + From-To-Date fields) overlapping the hero — clicking Search opens WhatsApp with the entered details (style/lead-capture only, not a live booking engine)
- Special Offers / Deals strip with coupon codes (click a code to copy it)
- Expandable WhatsApp chat widget (floating button opens a mini chat popup with quick options: Book a Flight, Hotel Enquiry, Holiday Package, Talk to an Agent)
- Newsletter / Deal Alerts signup box (front-end only — shows a thank-you message; connect to an email tool like Mailchimp later if needed)

Note: The search bar and newsletter form are front-end only (no live flight/hotel database or email backend) — they're designed to capture the enquiry and route it straight to your WhatsApp, since that's how you take bookings. If you later want live flight/hotel search results, that needs a paid travel API (e.g. Amadeus, TravelPayouts) integration.

Live Google Maps added:
- Contact section now has a live embedded Google Map showing the Jaipur, Rajasthan office location (no API key needed for this basic embed).
- Each Popular Destination card (Jaipur, Goa, Manali, Udaipur, Delhi, Mumbai) now has a "📍 Map" button (appears on hover) that opens that city's exact location in Google Maps in a new tab.
- To change the office map to an exact address later, replace "Jaipur,Rajasthan,India" in the iframe src (inside index.html, Contact section) with your full address or Google Maps place link.

Emotional quote banner added:
- A full-width quote section now sits between the Offers strip and the Services section, with a relatable line connecting everyday life to the feeling of travel: "Zindagi roz wahi office, wahi ghar, wahi raste hote hain — kabhi kabhi bas ek ticket kaafi hota hai sab kuch badalne ke liye."
- Wording is easy to change — just edit the text inside the <section class="quote-band"> block in index.html, or ask for a different line/tone anytime.

AI Tools added (new "AI Tools" section + smarter chat widget):
1. AI Trip Planner — pick destination (or "Surprise Me"), days, budget level & who you're travelling with -> generates a day-wise itinerary instantly, with a "Get This Trip Quoted" WhatsApp button.
2. AI Budget Estimator — pick destination, days, people & hotel category -> instantly estimates hotel + travel + food + misc costs with a total, plus a "Get Exact Quote" WhatsApp button.
3. AI Chatbot — the WhatsApp chat widget now has a text box where visitors can type questions (e.g. "how do I book", "goa price", "cancellation policy") and get an instant smart reply, with a fallback that routes to WhatsApp/agent if it doesn't recognize the question.

IMPORTANT — how this "AI" works:
These tools use smart rule-based logic built directly into the website (JavaScript), NOT a live ChatGPT/Claude-style API connection. This is intentional: connecting a real AI API from a plain HTML file would require exposing a secret API key in the page source, which is a serious security risk. The current tools give visitors an instant, AI-style experience (itinerary ideas, cost estimates, Q&A) while keeping the site 100% secure and free to run (no API costs).
If you ever want a real live AI chatbot (trained on your own data, hosted securely), that needs a small backend server — let me know and we can plan that separately.

Design polish pass added:
- Mobile hamburger menu now fully works (tap ☰ to open a dropdown menu on phones/tablets)
- Smooth "fade up" scroll animations on section headers, cards, packages, testimonials, FAQ items, deals and forms as you scroll down
- Sticky header now gets a subtle shadow once you start scrolling
- New "Back to Top" floating button (bottom-left) appears after scrolling down
- Browser tab favicon added (✈️ airplane icon)
- Staggered card animations so grids (services, packages, testimonials, deals) animate in one after another instead of all at once

BUG FIX: A missing closing bracket in the JavaScript was breaking the entire script (this made features look "missing" since the animations kept everything invisible until scroll-triggered, but the broken script never triggered them). Fixed and verified — all features (search bar, AI tools, chatbot, forms, animations, maps) now work correctly.

Teerth Yatra (Temple Pilgrimage) section added:
- New section between "Popular Destinations" and "Travel More, Create Memories" (also linked in nav as "Teerth Yatra")
- Krishna Mandir: Shri Krishna Janmabhoomi Mandir, Mathura, UP (mentions nearby Banke Bihari Mandir, Vrindavan)
- Ram Mandir: Shri Ram Janmabhoomi Mandir, Ayodhya, UP
- Shiv Mandir: Shri Kashi Vishwanath Mandir, Varanasi, UP (one of the 12 Jyotirlingas)
- Each card has a "📍 View on Map" button -> opens the exact live Google Maps location for customers to navigate there, and a "🙏 Plan Yatra" button -> opens WhatsApp to enquire about a pilgrimage trip package.
- Card visuals use icon-based designs (not stock photos) since these are specific real religious sites — swap in your own verified photos of each temple anytime for a more authentic look.
