VS Travels India - Website
===========================
1. Extract this zip file.
2. Double-click index.html to open it in your browser.
3. To host it live, upload index.html to any hosting service (Hostinger, GitHub Pages, Netlify, etc.) or send it to a web developer to connect a domain.

Contact details, WhatsApp number, and email already used in the site:
WhatsApp/Call: 9587370020
Email: vstravelsindiaa@gmail.com
Location: Jaipur, Rajasthan, India

Note: Images are loaded from free stock photo sources (Unsplash) via internet links, so an internet connection is needed to see them. Replace image URLs in index.html with your own hosted photos any time.
